package parkinglogsystem;

import java.sql.*;
import java.util.Vector;

public class ParkingService {
    public void vehicleEntry(String plate, String owner, String vehicleType, String attendant) throws SQLException {
        String sql = "INSERT INTO parking_logs(plate_number, owner_name, vehicle_type, entry_time, status, attendant) VALUES(?,?,?,NOW(),'PARKED',?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, plate.trim().toUpperCase());
            ps.setString(2, owner.trim());
            ps.setString(3, vehicleType);
            ps.setString(4, attendant);
            ps.executeUpdate();
        }
    }

    public void vehicleExit(String plate) throws SQLException {
        String sql = "UPDATE parking_logs SET exit_time=NOW(), status='EXITED' WHERE plate_number=? AND status='PARKED'";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, plate.trim().toUpperCase());
            if (ps.executeUpdate() == 0) throw new SQLException("No currently parked vehicle found with that plate number.");
        }
    }

    public Vector<Vector<Object>> getLogs(String filter) throws SQLException {
        Vector<Vector<Object>> rows = new Vector<>();
        String sql = "SELECT id, plate_number, owner_name, vehicle_type, entry_time, exit_time, status, attendant " +
                "FROM parking_logs WHERE (?='' OR plate_number LIKE ? OR owner_name LIKE ?) ORDER BY entry_time DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            String f = filter == null ? "" : filter.trim();
            ps.setString(1, f);
            ps.setString(2, "%" + f + "%");
            ps.setString(3, "%" + f + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getInt("id"));
                    row.add(rs.getString("plate_number"));
                    row.add(rs.getString("owner_name"));
                    row.add(rs.getString("vehicle_type"));
                    row.add(rs.getTimestamp("entry_time"));
                    row.add(rs.getTimestamp("exit_time"));
                    row.add(rs.getString("status"));
                    row.add(rs.getString("attendant"));
                    rows.add(row);
                }
            }
        }
        return rows;
    }

    public void deactivateUser(int userId) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE users SET active=0 WHERE id=?")) {
            ps.setInt(1, userId);
            ps.executeUpdate();
        }
    }
}
