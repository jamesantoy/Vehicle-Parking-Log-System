package parkinglogsystem;

import javax.swing.*;
import java.awt.*;

public class Report extends JPanel {
    private final ParkingService service;
    private final ViewVehicle view;

    public Report(ParkingService service) {
        this.service = service;
        setLayout(new BorderLayout(8, 8));
        view = new ViewVehicle(service);
        add(view, BorderLayout.CENTER);
        JButton refresh = new JButton("Refresh report");
        refresh.addActionListener(e -> view.load());
        JPanel p = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        p.add(refresh);
        add(p, BorderLayout.SOUTH);
    }
}
