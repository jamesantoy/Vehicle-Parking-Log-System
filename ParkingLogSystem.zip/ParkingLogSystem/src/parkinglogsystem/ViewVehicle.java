package parkinglogsystem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ViewVehicle extends JPanel {
    private final ParkingService service;
    private final DefaultTableModel model = UI.model("ID", "Plate", "Owner", "Type", "Entry", "Exit", "Status", "Attendant");
    private final JTable table = new JTable(model);
    private final JTextField search = new JTextField(20);

    public ViewVehicle(ParkingService service) {
        this.service = service;
        setLayout(new BorderLayout(8, 8));
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Search plate / owner:")); top.add(search);
        JButton find = new JButton("Search"), refresh = new JButton("Refresh");
        top.add(find); top.add(refresh);
        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        find.addActionListener(e -> load());
        refresh.addActionListener(e -> { search.setText(""); load(); });
        load();
    }

    public void load() {
        try { UI.fill(model, service.getLogs(search.getText())); }
        catch (Exception ex) { UI.error(this, ex); }
    }
}
