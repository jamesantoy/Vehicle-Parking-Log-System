package parkinglogsystem;

import javax.swing.*;
import java.awt.*;

public class Registration extends JFrame {
    private final JTextField fullName = new JTextField(20);
    private final JTextField username = new JTextField(20);
    private final JPasswordField password = new JPasswordField(20);
    private final JComboBox<String> role = new JComboBox<>(new String[]{"ATTENDANT", "SUPERVISOR"});

    public Registration() {
        setTitle("Create Account");
        setSize(420, 300);
        setLocationRelativeTo(null);
        JPanel p = new JPanel(new GridLayout(5, 2, 8, 8));
        p.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
        p.add(new JLabel("Full name")); p.add(fullName);
        p.add(new JLabel("Username")); p.add(username);
        p.add(new JLabel("Password")); p.add(password);
        p.add(new JLabel("Role")); p.add(role);
        JButton save = new JButton("Create account");
        JButton cancel = new JButton("Cancel");
        p.add(save); p.add(cancel);
        add(p);
        save.addActionListener(e -> save());
        cancel.addActionListener(e -> dispose());
    }

    private void save() {
        if (fullName.getText().trim().isEmpty() || username.getText().trim().isEmpty()
                || password.getPassword().length < 6) {
            UI.info(this, "Enter your name and username, and use a password of at least 6 characters.");
            return;
        }
        try {
            new AuthService().register(fullName.getText(), username.getText(),
                    new String(password.getPassword()), (String) role.getSelectedItem());
            UI.info(this, "Account created. You can now log in.");
            dispose();
        } catch (Exception ex) { UI.error(this, ex); }
    }
}
