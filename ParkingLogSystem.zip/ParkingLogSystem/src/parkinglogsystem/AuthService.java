package parkinglogsystem;

import java.sql.*;

public class AuthService {
    public User login(String username, String password) throws SQLException {
        String sql = "SELECT id, username, full_name, role FROM users WHERE username=? AND password_hash=? AND active=1";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username.trim());
            ps.setString(2, PasswordUtil.hash(password));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return new User(rs.getInt("id"), rs.getString("username"),
                        rs.getString("full_name"), rs.getString("role"));
            }
        }
        return null;
    }

    public void register(String fullName, String username, String password, String role) throws SQLException {
        String sql = "INSERT INTO users(full_name, username, password_hash, role) VALUES(?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, fullName.trim());
            ps.setString(2, username.trim());
            ps.setString(3, PasswordUtil.hash(password));
            ps.setString(4, role);
            ps.executeUpdate();
        }
    }
}
