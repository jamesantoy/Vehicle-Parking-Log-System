package parkinglogsystem;

import javax.swing.*;

public class Unregistration {
    // User account deactivation is available in the Supervisor tab.
    // This compatibility class is retained to match the project structure in the screenshot.
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null,
                "To deactivate an account, log in as a SUPERVISOR and open the Supervisor tab.");
    }
}
