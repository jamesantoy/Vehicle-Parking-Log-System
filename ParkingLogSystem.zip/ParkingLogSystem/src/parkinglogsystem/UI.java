package parkinglogsystem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.Vector;

public final class UI {
    private UI() {}
    public static void error(Component parent, Exception ex) {
        JOptionPane.showMessageDialog(parent, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    public static void info(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Parking Log System", JOptionPane.INFORMATION_MESSAGE);
    }
    public static DefaultTableModel model(String... columns) {
        return new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int row, int col) { return false; }
        };
    }
    public static void fill(DefaultTableModel model, Vector<Vector<Object>> rows) {
        model.setRowCount(0);
        for (Vector<Object> row : rows) model.addRow(row);
    }
    public static JPanel fieldPanel(JComponent... fields) {
        JPanel p = new JPanel(new GridLayout(fields.length, 1, 6, 6));
        for (JComponent f : fields) p.add(f);
        return p;
    }
}
