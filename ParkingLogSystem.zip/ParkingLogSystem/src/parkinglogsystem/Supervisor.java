package parkinglogsystem;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class Supervisor extends JPanel {
    private final DefaultListModel<String> users = new DefaultListModel<>();
    private final JList<String> list = new JList<>(users);
    private final java.util.List<Integer> ids = new java.util.ArrayList<>();

    public Supervisor() {
        setLayout(new BorderLayout(8, 8));
        add(new JScrollPane(list), BorderLayout.CENTER);
        JButton refresh = new JButton("Refresh users");
        JButton deactivate = new JButton("Deactivate selected user");
        JPanel p = new JPanel();
        p.add(refresh); p.add(deactivate);
        add(p, BorderLayout.SOUTH);
        refresh.addActionListener(e -> load());
        deactivate.addActionListener(e -> deactivate());
        load();
    }

    private void load() {
        users.clear(); ids.clear();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT id, full_name, username, role FROM users WHERE active=1 ORDER BY full_name");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                ids.add(rs.getInt("id"));
                users.addElement(rs.getString("full_name") + " | " + rs.getString("username") + " | " + rs.getString("role"));
            }
        } catch (Exception ex) { UI.error(this, ex); }
    }

    private void deactivate() {
        int index = list.getSelectedIndex();
        if (index < 0) { UI.info(this, "Select a user first."); return; }
        if (JOptionPane.showConfirmDialog(this, "Deactivate this account?", "Confirm",
                JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try {
            new ParkingService().deactivateUser(ids.get(index));
            UI.info(this, "User deactivated.");
            load();
        } catch (Exception ex) { UI.error(this, ex); }
    }
}
