package parkinglogsystem;

import javax.swing.*;
import java.awt.*;

public class ParkingAttendant extends JPanel {
    public ParkingAttendant(User user, ParkingService service) {
        setLayout(new BorderLayout(10, 10));
        JPanel entry = new JPanel(new GridLayout(5, 2, 8, 8));
        entry.setBorder(BorderFactory.createTitledBorder("Record vehicle entry"));
        JTextField plate = new JTextField();
        JTextField owner = new JTextField();
        JComboBox<String> type = new JComboBox<>(new String[]{"Car", "Motorcycle", "Van", "Truck", "Other"});
        JButton save = new JButton("Save entry");
        entry.add(new JLabel("Plate number")); entry.add(plate);
        entry.add(new JLabel("Owner name")); entry.add(owner);
        entry.add(new JLabel("Vehicle type")); entry.add(type);
        entry.add(new JLabel("")); entry.add(save);
        JButton exit = new JButton("Record vehicle exit");
        JTextField exitPlate = new JTextField();
        JPanel exitPanel = new JPanel(new GridLayout(2, 2, 8, 8));
        exitPanel.setBorder(BorderFactory.createTitledBorder("Vehicle exit"));
        exitPanel.add(new JLabel("Plate number")); exitPanel.add(exitPlate);
        exitPanel.add(new JLabel("")); exitPanel.add(exit);
        add(entry, BorderLayout.NORTH);
        add(exitPanel, BorderLayout.CENTER);
        save.addActionListener(e -> {
            if (plate.getText().trim().isEmpty() || owner.getText().trim().isEmpty()) {
                UI.info(this, "Plate number and owner name are required."); return;
            }
            try {
                service.vehicleEntry(plate.getText(), owner.getText(), (String) type.getSelectedItem(), user.getUsername());
                UI.info(this, "Vehicle entry saved.");
                plate.setText(""); owner.setText("");
            } catch (Exception ex) { UI.error(this, ex); }
        });
        exit.addActionListener(e -> {
            try { service.vehicleExit(exitPlate.getText()); UI.info(this, "Vehicle exit saved."); exitPlate.setText(""); }
            catch (Exception ex) { UI.error(this, ex); }
        });
    }
}
