package parkinglogsystem;

import javax.swing.*;
import java.awt.*;

public class LOGIN extends JFrame {
    private final JTextField username = new JTextField(18);
    private final JPasswordField password = new JPasswordField(18);
    private final AuthService auth = new AuthService();

    public LOGIN() {
        setTitle("Parking Log System - Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(380, 250);
        setLocationRelativeTo(null);
        JPanel form = new JPanel(new GridLayout(3, 2, 8, 8));
        form.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));
        form.add(new JLabel("Username")); form.add(username);
        form.add(new JLabel("Password")); form.add(password);
        JButton login = new JButton("Login");
        JButton register = new JButton("Register");
        form.add(login); form.add(register);
        add(form, BorderLayout.CENTER);
        login.addActionListener(e -> doLogin());
        register.addActionListener(e -> new Registration().setVisible(true));
        getRootPane().setDefaultButton(login);
    }

    private void doLogin() {
        try {
            User user = auth.login(username.getText(), new String(password.getPassword()));
            if (user == null) { UI.info(this, "Invalid username or password."); return; }
            dispose();
            new ParkingLogSystem(user).setVisible(true);
        } catch (Exception ex) { UI.error(this, ex); }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LOGIN().setVisible(true));
    }
}
