package parkinglogsystem;

import java.sql.Connection;

public class TestConnection {
    public static void main(String[] args) {
        try (Connection ignored = DBConnection.getConnection()) {
            System.out.println("Database connection successful.");
        } catch (Exception ex) {
            System.err.println("Database connection failed: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}
