package parkinglogsystem;

import javax.swing.*;
import java.awt.*;

public class ParkingLogSystem extends JFrame {
    private final User user;
    private final ParkingService service = new ParkingService();

    public ParkingLogSystem(User user) {
        this.user = user;
        setTitle("Parking Log System - " + user.getRole());
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 560);
        setLocationRelativeTo(null);

        JLabel welcome = new JLabel("Welcome, " + user.getFullName() + " (" + user.getRole() + ")");
        welcome.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        add(welcome, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Parking", new ParkingAttendant(user, service));
        tabs.addTab("Vehicles / Logs", new ViewVehicle(service));
        tabs.addTab("Reports", new Report(service));
        if ("SUPERVISOR".equals(user.getRole())) tabs.addTab("Supervisor", new Supervisor());
        add(tabs, BorderLayout.CENTER);

        JButton logout = new JButton("Log out");
        logout.addActionListener(e -> { dispose(); new LOGIN().setVisible(true); });
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.add(logout);
        add(bottom, BorderLayout.SOUTH);
    }
}
