CREATE DATABASE IF NOT EXISTS parkinglogsystem;
USE parkinglogsystem;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    username VARCHAR(60) NOT NULL UNIQUE,
    password_hash CHAR(64) NOT NULL,
    role ENUM('ATTENDANT','SUPERVISOR') NOT NULL DEFAULT 'ATTENDANT',
    active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS parking_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    plate_number VARCHAR(30) NOT NULL,
    owner_name VARCHAR(120) NOT NULL,
    vehicle_type VARCHAR(30) NOT NULL,
    entry_time DATETIME NOT NULL,
    exit_time DATETIME NULL,
    status ENUM('PARKED','EXITED') NOT NULL DEFAULT 'PARKED',
    attendant VARCHAR(60) NOT NULL,
    INDEX idx_plate_status (plate_number, status),
    INDEX idx_entry_time (entry_time)
);

-- Create your first account through the Register button after starting the app.
-- For a supervisor account, choose SUPERVISOR in the registration form.
