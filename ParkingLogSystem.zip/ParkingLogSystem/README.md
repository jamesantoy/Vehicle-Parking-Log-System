# Parking Log System (Java Swing + MySQL)

## Included features
- Login and account registration
- Attendant: record vehicle entry and exit
- Search and view parking logs
- Reports tab (all parking logs with refresh/search)
- Supervisor: view active users and deactivate accounts
- MySQL connection test

## Requirements
- JDK 8 or newer
- NetBeans IDE (Java with Ant) or another Java IDE
- MySQL Server / XAMPP
- MySQL Connector/J (JDBC driver)

## Setup
1. Start MySQL in XAMPP.
2. Open phpMyAdmin or MySQL client and import `database.sql`.
3. In `src/parkinglogsystem/DBConnection.java`, check:
   - URL database name: `parkinglogsystem`
   - USER: `root`
   - PASSWORD: usually empty in a default XAMPP setup; change it if yours is different.
4. Add MySQL Connector/J to the project libraries/classpath.
   - NetBeans: right-click Libraries > Add JAR/Folder > select the MySQL Connector/J JAR.
5. Run `TestConnection.java`. It should print `Database connection successful.`
6. Run `LOGIN.java`.
7. Use Register to create an account. Choose SUPERVISOR for supervisor access.

## Important notes
- This is a clean implementation based on the class names visible in your screenshot; the screenshot did not include the original source code or detailed requirements.
- Registration permits choosing a supervisor role for easy classroom/demo setup. For a real deployment, restrict supervisor creation to an administrator.
- Passwords are stored as SHA-256 hashes for this basic school-project implementation. For production, use a password-hashing algorithm such as BCrypt or Argon2.
- The report currently displays the parking log records; it does not generate PDF/Excel exports or calculate fees because those rules were not visible in the screenshot.
